package com.mashaswape

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Fortschritt und Steuerung, gemeinsam für Oberfläche und Hintergrunddienst. */
object Progress {
    @Volatile var running = false
    @Volatile var paused = false
    @Volatile var stop = false
    @Volatile var text = ""
    @Volatile var pct = 0
}

/** Ein Video-Auftrag. Wird als Datei gespeichert, damit er nach einem Abbruch fortgesetzt werden kann. */
class Project(
    var id: String = "",
    var name: String = "",
    var uri: String = "",
    var startSec: Int = 0,
    var lenSec: Int = 0,
    var maxSide: Int = 1280,
    var fps: Int = 10,
    var bpp: Float = 0.17f,
    var detectEvery: Int = 1,
    var colorMatch: Float = 0.45f,
    var useOcc: Boolean = false,
    var chunkSec: Int = 60,
    var personNames: List<String> = emptyList(),
    var allFaces: Boolean = false,
    var refAssign: List<Int> = emptyList(),
    var state: String = "wartet",     // wartet, läuft, gestoppt, fertig, fehler
    var doneChunks: Int = 0,
    var totalChunks: Int = 0,
    var msg: String = "",
    var outUri: String = "",
    var enhModel: String = "",        // Dateiname des Verbesserers (leer = aus)
    var enhStrength: Float = 0.8f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("uri", uri)
        put("startSec", startSec); put("lenSec", lenSec); put("maxSide", maxSide); put("fps", fps)
        put("bpp", bpp.toDouble()); put("detectEvery", detectEvery); put("colorMatch", colorMatch.toDouble())
        put("useOcc", useOcc); put("chunkSec", chunkSec)
        put("personNames", JSONArray(personNames)); put("allFaces", allFaces)
        put("refAssign", JSONArray(refAssign))
        put("state", state); put("doneChunks", doneChunks); put("totalChunks", totalChunks)
        put("msg", msg); put("outUri", outUri)
        put("enhModel", enhModel); put("enhStrength", enhStrength.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject): Project {
            val pn = o.optJSONArray("personNames") ?: JSONArray()
            val ra = o.optJSONArray("refAssign") ?: JSONArray()
            return Project(
                id = o.optString("id"), name = o.optString("name"), uri = o.optString("uri"),
                startSec = o.optInt("startSec"), lenSec = o.optInt("lenSec"),
                maxSide = o.optInt("maxSide", 1280), fps = o.optInt("fps", 10),
                bpp = o.optDouble("bpp", 0.17).toFloat(), detectEvery = o.optInt("detectEvery", 1),
                colorMatch = o.optDouble("colorMatch", 0.45).toFloat(), useOcc = o.optBoolean("useOcc"),
                chunkSec = o.optInt("chunkSec", 60),
                personNames = List(pn.length()) { pn.getString(it) },
                allFaces = o.optBoolean("allFaces"),
                refAssign = List(ra.length()) { ra.getInt(it) },
                state = o.optString("state", "wartet"), doneChunks = o.optInt("doneChunks"),
                totalChunks = o.optInt("totalChunks"), msg = o.optString("msg"),
                outUri = o.optString("outUri"),
                enhModel = o.optString("enhModel", ""),
                enhStrength = o.optDouble("enhStrength", 0.8).toFloat()
            )
        }
    }
}

object Store {
    private fun root(ctx: Context) = File(ctx.filesDir, "projects").apply { mkdirs() }
    fun projDir(ctx: Context, id: String) = File(root(ctx), id).apply { mkdirs() }

    @Synchronized
    fun save(ctx: Context, p: Project) {
        File(projDir(ctx, p.id), "project.json").writeText(p.toJson().toString())
    }

    @Synchronized
    fun all(ctx: Context): List<Project> {
        val list = ArrayList<Project>()
        for (d in root(ctx).listFiles() ?: emptyArray<File>()) {
            val f = File(d, "project.json")
            if (!f.exists()) continue
            try { list.add(Project.fromJson(JSONObject(f.readText()))) } catch (e: Exception) { }
        }
        return list.sortedBy { it.id }
    }

    @Synchronized
    fun delete(ctx: Context, id: String) {
        File(root(ctx), id).deleteRecursively()
    }

    private fun toBytes(list: List<FloatArray>): ByteArray {
        val n = list.sumOf { it.size }
        val bb = ByteBuffer.allocate(n * 4).order(ByteOrder.LITTLE_ENDIAN)
        for (a in list) for (x in a) bb.putFloat(x)
        return bb.array()
    }

    private fun toFloats(bytes: ByteArray): List<FloatArray> {
        val fb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
        val out = ArrayList<FloatArray>()
        while (fb.remaining() >= 512) {
            val a = FloatArray(512)
            fb.get(a)
            out.add(a)
        }
        return out
    }

    fun saveRefs(ctx: Context, id: String, refs: List<FloatArray>) {
        File(projDir(ctx, id), "refs.bin").writeBytes(toBytes(refs))
    }

    fun loadRefs(ctx: Context, id: String): List<FloatArray> {
        val f = File(projDir(ctx, id), "refs.bin")
        return if (f.exists()) toFloats(f.readBytes()) else emptyList()
    }

    // ---------- gespeicherte Personen ----------
    private fun personDir(ctx: Context) = File(ctx.filesDir, "persons").apply { mkdirs() }

    fun cleanName(n: String): String =
        n.replace(Regex("[^A-Za-z0-9ÄÖÜäöüß_ -]"), "_").trim().take(24)

    fun personNames(ctx: Context): List<String> =
        (personDir(ctx).listFiles() ?: emptyArray<File>()).filter { it.name.endsWith(".lat") }
            .map { it.name.removeSuffix(".lat") }.sorted()

    fun savePerson(ctx: Context, name: String, latent: FloatArray): String {
        val clean = cleanName(name).ifEmpty { "Person" }
        File(personDir(ctx), "$clean.lat").writeBytes(toBytes(listOf(latent)))
        return clean
    }

    fun loadPerson(ctx: Context, name: String): FloatArray? {
        val f = File(personDir(ctx), "$name.lat")
        return if (f.exists()) toFloats(f.readBytes()).firstOrNull() else null
    }

    fun deletePerson(ctx: Context, name: String) {
        File(personDir(ctx), "$name.lat").delete()
    }
}
