package com.mashaswape

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Video in Teilstücken: jedes Teilstück wird als eigene MP4-Datei fertig gespeichert.
 * Nach einem Abbruch geht es beim nächsten unfertigen Teilstück weiter; am Ende werden alle zusammengefügt.
 */
object VideoPipeline {

    class Plan(
        val w: Int, val h: Int, val total: Int, val chunkFrames: Int,
        val chunks: Int, val startUs: Long
    )

    fun plan(ctx: Context, uri: Uri, p: Project): Plan? {
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(ctx, uri)
            val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val mw = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val mh = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (durMs <= 0 || mw <= 0 || mh <= 0) return null
            val vw = if (rot % 180 == 90) mh else mw
            val vh = if (rot % 180 == 90) mw else mh
            val scale = min(1f, p.maxSide.toFloat() / max(vw, vh))
            val w = max(16, ((vw * scale).toInt() / 16) * 16)
            val h = max(16, ((vh * scale).toInt() / 16) * 16)
            val startMs = min(p.startSec * 1000L, max(0L, durMs - 1000L))
            val availMs = durMs - startMs
            val useMs = if (p.lenSec <= 0) availMs else min(p.lenSec * 1000L, availMs)
            val total = max(1, (useMs * p.fps / 1000).toInt())
            val chunkFrames = max(p.fps, p.chunkSec * p.fps)
            val chunks = (total + chunkFrames - 1) / chunkFrames
            return Plan(w, h, total, chunkFrames, chunks, startMs * 1000L)
        } catch (e: Exception) {
            return null
        } finally {
            mmr.release()
        }
    }

    private fun detectTracks(
        eng: FaceEngine, fr: Bitmap, refs: List<FloatArray>, p: Project, robust: Boolean = true
    ): List<Track> {
        val faces = (if (robust) eng.detectRobust(fr) else eng.detect(fr)).sortedByDescending { it.area }
        if (refs.isNotEmpty()) {
            // Alle (Ähnlichkeit, Gesicht, Referenz) über der Schwelle, beste zuerst; jedes Gesicht und
            // jede Referenz wird pro Bild höchstens einmal vergeben.
            val cand = ArrayList<Triple<Float, Int, Int>>()
            for ((fi, f) in faces.withIndex()) {
                val e = eng.embed(fr, f)
                for ((ri, r) in refs.withIndex()) {
                    val s = eng.cosine(e, r)
                    if (s >= 0.25f) cand.add(Triple(s, fi, ri))
                }
            }
            cand.sortByDescending { it.first }
            val usedFace = BooleanArray(faces.size)
            val usedRef = BooleanArray(refs.size)
            val refOfFace = IntArray(faces.size) { -1 }
            for ((_, fi, ri) in cand) {
                if (usedFace[fi] || usedRef[ri]) continue
                usedFace[fi] = true
                usedRef[ri] = true
                refOfFace[fi] = ri
            }
            val out = ArrayList<Track>()
            for ((fi, f) in faces.withIndex()) {
                val ri = refOfFace[fi]
                if (ri >= 0 && ri < p.refAssign.size && p.refAssign[ri] >= 0) {
                    out.add(Track(f, p.refAssign[ri]))
                }
            }
            return out
        }
        return if (p.allFaces) faces.map { Track(it, 0) } else faces.take(1).map { Track(it, 0) }
    }

    /** Verarbeitet ein Teilstück in die Datei out. Gibt true zurück, wenn es vollständig fertig ist. */
    fun processChunk(
        ctx: Context, uri: Uri, eng: FaceEngine, latents: List<FloatArray>, refs: List<FloatArray>,
        p: Project, plan: Plan, firstFrame: Int, frames: Int, out: File, onFrame: (Int) -> Unit
    ): Boolean {
        val fps = p.fps
        val w = plan.w
        val h = plan.h
        val chunkStartUs = plan.startUs + firstFrame * 1_000_000L / fps
        val bitrate = (w.toLong() * h * fps * p.bpp).toLong().coerceIn(500_000L, 40_000_000L).toInt()

        val mmr = MediaMetadataRetriever()
        mmr.setDataSource(ctx, uri)

        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val ex = MediaExtractor()
        var audioIdx = -1
        try {
            ex.setDataSource(ctx, uri, null)
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)
                if (mime != null && mime.startsWith("audio/")) { audioIdx = i; break }
            }
        } catch (e: Exception) {
            audioIdx = -1
        }

        var vTrack = -1
        var aTrack = -1
        var started = false
        var outCount = 0
        val info = MediaCodec.BufferInfo()

        fun drain(end: Boolean) {
            var spins = 0
            while (true) {
                val idx = enc.dequeueOutputBuffer(info, if (end) 10_000L else 0L)
                if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!end) return
                    spins++
                    if (spins > 600) return
                    continue
                }
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    vTrack = muxer.addTrack(enc.outputFormat)
                    if (audioIdx >= 0) {
                        try { aTrack = muxer.addTrack(ex.getTrackFormat(audioIdx)) } catch (e: Exception) { aTrack = -1 }
                    }
                    muxer.start()
                    started = true
                    continue
                }
                if (idx < 0) continue
                val buf = enc.getOutputBuffer(idx)
                if (buf != null && info.size > 0 && started &&
                    (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                ) {
                    info.presentationTimeUs = outCount * 1_000_000L / fps
                    outCount++
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    muxer.writeSampleData(vTrack, buf, info)
                }
                enc.releaseOutputBuffer(idx, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }

        var ok = true
        var aborted = false
        var tracks: List<Track> = emptyList()
        var prevGray: Tracker.Gray? = null
        var emptyStreak = 0
        // Verbesserer im Video: nur wenn gewählt und die Modelldatei vorhanden ist
        var enhOn = p.enhModel.isNotEmpty() && File(File(ctx.filesDir, "models"), p.enhModel).exists()
        try {
            for (i in 0 until frames) {
                while (Progress.paused && !Progress.stop) Thread.sleep(300)
                if (Progress.stop) { aborted = true; break }

                val t = chunkStartUs + i * 1_000_000L / fps
                var fr = mmr.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST, w, h) ?: break
                if (fr.width != w || fr.height != h) fr = Bitmap.createScaledBitmap(fr, w, h, true)

                val needGray = p.detectEvery > 1
                val cg = if (needGray) Tracker.toGray(fr) else null
                var tracked: List<Track>? = null
                var frozen = false
                val pg = prevGray
                if (needGray && cg != null && pg != null && i % p.detectEvery != 0 && tracks.isNotEmpty()) {
                    tracked = Tracker.update(pg, cg, tracks)
                    if (tracked == null && i % (p.detectEvery * 2) != 0) {
                        // Nachverfolgung unsicher: letzten Stand einfrieren statt sofort neu zu suchen;
                        // harte Neuerkennung nur alle detectEvery * 2 Bilder
                        tracked = tracks
                        frozen = true
                    }
                }
                // Ohne Gesicht in den letzten Bildern die teure Mehrfach-Suche nur jedes 3. Bild
                tracks = tracked ?: detectTracks(eng, fr, refs, p, emptyStreak < 2 || i % 3 == 0)
                if (!frozen) prevGray = cg
                emptyStreak = if (tracks.isEmpty()) emptyStreak + 1 else 0

                var res: Bitmap = fr
                for (tr in tracks) {
                    val lat = latents[tr.person.coerceIn(0, latents.size - 1)]
                    res = eng.swap(res, tr.face, lat, p.colorMatch, p.useOcc)
                }
                // Restore: mindestens jedes 3. Bild, sowie immer bei Gesichtern unter 96 px
                if (enhOn) {
                    for (tr in tracks) {
                        val side = min(tr.face.x2 - tr.face.x1, tr.face.y2 - tr.face.y1)
                        if (i % 3 == 0 || side < 96f) {
                            try {
                                res = eng.enhance(res, tr.face, p.enhModel, p.enhStrength)
                            } catch (e: Throwable) {
                                enhOn = false   // Verbesserer fällt aus: Video läuft ohne ihn weiter
                                break
                            }
                        }
                    }
                }

                val c = surface.lockCanvas(null)
                c.drawBitmap(res, 0f, 0f, null)
                surface.unlockCanvasAndPost(c)
                drain(false)
                onFrame(i + 1)
            }
            if (!aborted) {
                enc.signalEndOfInputStream()
                drain(true)

                if (started && aTrack >= 0) {
                    try {
                        ex.selectTrack(audioIdx)
                        ex.seekTo(chunkStartUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                        val limitUs = chunkStartUs + outCount * 1_000_000L / fps
                        val buf = ByteBuffer.allocate(1 shl 20)
                        val ai = MediaCodec.BufferInfo()
                        while (true) {
                            val size = ex.readSampleData(buf, 0)
                            val st = ex.sampleTime
                            if (size < 0 || st < 0 || st >= limitUs) break
                            if (st >= chunkStartUs) {
                                ai.set(0, size, st - chunkStartUs, ex.sampleFlags)
                                muxer.writeSampleData(aTrack, buf, ai)
                            }
                            ex.advance()
                        }
                    } catch (e: Exception) {
                        // Ton ist optional
                    }
                }
                if (!started) ok = false
            }
        } catch (e: Throwable) {
            ok = false
            p.msg = "Fehler: ${e.message}"
        } finally {
            try { enc.stop() } catch (e: Exception) {}
            try { enc.release() } catch (e: Exception) {}
            try { surface.release() } catch (e: Exception) {}
            try { if (started) muxer.stop() } catch (e: Exception) { ok = false }
            try { muxer.release() } catch (e: Exception) {}
            try { ex.release() } catch (e: Exception) {}
            try { mmr.release() } catch (e: Exception) {}
        }
        if (!ok || aborted) {
            out.delete()
            return false
        }
        return true
    }

    private fun copyTrack(
        ex: MediaExtractor, srcIdx: Int, muxer: MediaMuxer, dstTrack: Int,
        offsetUs: Long, buf: ByteBuffer, info: MediaCodec.BufferInfo
    ) {
        ex.selectTrack(srcIdx)
        ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        while (true) {
            val size = ex.readSampleData(buf, 0)
            if (size < 0) break
            info.set(0, size, ex.sampleTime + offsetUs, ex.sampleFlags)
            muxer.writeSampleData(dstTrack, buf, info)
            ex.advance()
        }
        ex.unselectTrack(srcIdx)
    }

    /** Fügt die fertigen Teilstücke zu einer MP4 zusammen. */
    fun concat(files: List<File>, durationsUs: List<Long>, out: File): Boolean {
        val ex0 = MediaExtractor()
        var vf: MediaFormat? = null
        var af: MediaFormat? = null
        try {
            ex0.setDataSource(files[0].absolutePath)
            for (i in 0 until ex0.trackCount) {
                val f = ex0.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("video/") && vf == null) vf = f
                else if (m.startsWith("audio/") && af == null) af = f
            }
        } finally {
            ex0.release()
        }
        val videoFormat = vf ?: return false

        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val vt = muxer.addTrack(videoFormat)
        var at = -1
        if (af != null) {
            try { at = muxer.addTrack(af) } catch (e: Exception) { at = -1 }
        }
        muxer.start()
        val buf = ByteBuffer.allocate(4 shl 20)
        val info = MediaCodec.BufferInfo()
        var offset = 0L
        var ok = true
        try {
            for ((idx, f) in files.withIndex()) {
                val ex = MediaExtractor()
                try {
                    ex.setDataSource(f.absolutePath)
                    var vi = -1
                    var ai = -1
                    for (i in 0 until ex.trackCount) {
                        val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                        if (m.startsWith("video/") && vi < 0) vi = i
                        else if (m.startsWith("audio/") && ai < 0) ai = i
                    }
                    if (vi >= 0) copyTrack(ex, vi, muxer, vt, offset, buf, info)
                    if (ai >= 0 && at >= 0) copyTrack(ex, ai, muxer, at, offset, buf, info)
                } finally {
                    ex.release()
                }
                offset += durationsUs[idx]
            }
        } catch (e: Throwable) {
            ok = false
        }
        try { muxer.stop() } catch (e: Exception) { ok = false }
        try { muxer.release() } catch (e: Exception) {}
        return ok
    }
}
