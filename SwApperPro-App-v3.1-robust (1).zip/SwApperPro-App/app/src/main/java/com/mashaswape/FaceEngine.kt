package com.mashaswape

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.DoubleBuffer
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class Face(
    val x1: Float, val y1: Float, val x2: Float, val y2: Float,
    val score: Float, val kps: FloatArray
) {
    val area: Float get() = (x2 - x1) * (y2 - y1)
}

/** Teilt sich eine Engine zwischen Oberfläche und Hintergrunddienst (Modelle nur einmal im Speicher). */
object EngineHolder {
    private var eng: FaceEngine? = null
    private var key = ""

    @Synchronized
    fun get(dir: File, threads: Int, nnapi: Boolean): FaceEngine {
        val k = "$threads/$nnapi"
        val e = eng
        if (e != null && k == key) return e
        e?.close()
        val n = FaceEngine(dir, threads, nnapi)
        eng = n
        key = k
        return n
    }

    @Synchronized
    fun reset() {
        eng?.close()
        eng = null
        key = ""
    }
}

/**
 * Erkennung (SCRFD det_10g), Gesichts-Embedding (ArcFace w600k_r50), Tausch (InSwapper 128),
 * Verdeckungs-Maske (XSeg), Verbesserer (GFPGAN 1.4 / CodeFormer, 512 px).
 */
class FaceEngine(private val dir: File, threads: Int, nnapi: Boolean) {
    private val env = OrtEnvironment.getEnvironment()
    private val cpuOpts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(threads) }
    private val opts = OrtSession.SessionOptions().apply {
        setIntraOpNumThreads(threads)
        if (nnapi) {
            try { addNnapi() } catch (e: Exception) { /* ohne Beschleuniger weiter */ }
        }
    }

    private fun open(name: String): OrtSession {
        val path = File(dir, name).absolutePath
        return try {
            env.createSession(path, opts)
        } catch (e: Exception) {
            env.createSession(path, cpuOpts)
        }
    }

    private val det = open("det_10g.onnx")
    private val rec = open("w600k_r50.onnx")
    private val swp = open("inswapper_128.onnx")
    private val enhancers = HashMap<String, OrtSession>()
    private val occ: OrtSession? by lazy {
        // fehlt die Datei oder ist sie defekt: Verdeckungs-Schutz still überspringen
        try {
            if (File(dir, "xseg_1.onnx").exists()) open("xseg_1.onnx") else null
        } catch (e: Throwable) {
            null
        }
    }
    private val emap = FloatArray(512 * 512).also {
        ByteBuffer.wrap(File(dir, "emap.bin").readBytes()).order(ByteOrder.LITTLE_ENDIAN)
            .asFloatBuffer().get(it)
    }

    fun hasOcclusionModel(): Boolean = File(dir, "xseg_1.onnx").exists()

    fun close() {
        try { det.close() } catch (e: Exception) {}
        try { rec.close() } catch (e: Exception) {}
        try { swp.close() } catch (e: Exception) {}
        for (s in enhancers.values) try { s.close() } catch (e: Exception) {}
        try { occ?.close() } catch (e: Exception) {}
    }

    // ArcFace-Vorlage für 112 px (insightface face_align.arcface_dst)
    private val dst112 = floatArrayOf(
        38.2946f, 51.6963f, 73.5318f, 51.5014f, 56.0252f,
        71.7366f, 41.5493f, 92.3655f, 70.7299f, 92.2041f
    )

    // InSwapper 128: Maßstab 1.0, x-Verschiebung +8 px
    private val dst128 = FloatArray(10) { if (it % 2 == 0) dst112[it] + 8f else dst112[it] }

    // FFHQ-Vorlage der Verbesserer (normiert) mal 512
    private val dst512 = floatArrayOf(
        0.37691676f, 0.46864664f, 0.62285697f, 0.46912813f, 0.50123859f,
        0.61331904f, 0.39308822f, 0.72541100f, 0.61150205f, 0.72490465f
    ).let { t -> FloatArray(10) { t[it] * 512f } }

    private fun tensor(d: FloatArray, shape: LongArray) =
        OnnxTensor.createTensor(env, FloatBuffer.wrap(d), shape)

    private fun OnnxTensor.toArray(): FloatArray {
        val fb = this.floatBuffer
        val a = FloatArray(fb.remaining())
        fb.get(a)
        return a
    }

    private fun normalize(v: FloatArray): FloatArray {
        var s = 0.0
        for (x in v) s += (x * x).toDouble()
        val n = sqrt(s).toFloat() + 1e-9f
        return FloatArray(v.size) { v[it] / n }
    }

    /** Ähnlichkeitstransformation (Drehung + Skalierung + Verschiebung) von src nach dst, 5 Punkte. */
    private fun similarity(src: FloatArray, dst: FloatArray): Matrix {
        var mpx = 0.0; var mpy = 0.0; var mqx = 0.0; var mqy = 0.0
        for (i in 0 until 5) {
            mpx += src[2 * i]; mpy += src[2 * i + 1]
            mqx += dst[2 * i]; mqy += dst[2 * i + 1]
        }
        mpx /= 5; mpy /= 5; mqx /= 5; mqy /= 5
        var num1 = 0.0; var num2 = 0.0; var den = 0.0
        for (i in 0 until 5) {
            val px = src[2 * i] - mpx; val py = src[2 * i + 1] - mpy
            val qx = dst[2 * i] - mqx; val qy = dst[2 * i + 1] - mqy
            num1 += px * qx + py * qy
            num2 += px * qy - py * qx
            den += px * px + py * py
        }
        val a = num1 / den
        val b = num2 / den
        val tx = mqx - (a * mpx - b * mpy)
        val ty = mqy - (b * mpx + a * mpy)
        return Matrix().apply {
            setValues(
                floatArrayOf(
                    a.toFloat(), (-b).toFloat(), tx.toFloat(),
                    b.toFloat(), a.toFloat(), ty.toFloat(),
                    0f, 0f, 1f
                )
            )
        }
    }

    private fun alignTo(bmp: Bitmap, kps: FloatArray, dst: FloatArray, size: Int): Pair<Bitmap, Matrix> {
        val m = similarity(kps, dst)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(bmp, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return Pair(out, m)
    }

    private fun chw(bmp: Bitmap, mean: Float, std: Float): FloatArray {
        val n = bmp.width * bmp.height
        val px = IntArray(n)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val out = FloatArray(3 * n)
        for (i in 0 until n) {
            val c = px[i]
            out[i] = (((c shr 16) and 255) - mean) / std
            out[n + i] = (((c shr 8) and 255) - mean) / std
            out[2 * n + i] = ((c and 255) - mean) / std
        }
        return out
    }

    // ---------------- Erkennung ----------------
    fun detect(bmp: Bitmap, size: Int = 640): List<Face> {
        val ratio = min(size.toFloat() / bmp.width, size.toFloat() / bmp.height)
        val nw = max(1, (bmp.width * ratio).toInt())
        val nh = max(1, (bmp.height * ratio).toInt())
        val scaled = Bitmap.createScaledBitmap(bmp, nw, nh, true)
        val px = IntArray(nw * nh)
        scaled.getPixels(px, 0, nw, 0, 0, nw, nh)

        val plane = size * size
        val data = FloatArray(3 * plane) { -127.5f / 128f }
        for (y in 0 until nh) for (x in 0 until nw) {
            val c = px[y * nw + x]
            val o = y * size + x
            data[o] = (((c shr 16) and 255) - 127.5f) / 128f
            data[plane + o] = (((c shr 8) and 255) - 127.5f) / 128f
            data[2 * plane + o] = ((c and 255) - 127.5f) / 128f
        }

        val found = ArrayList<Face>()
        tensor(data, longArrayOf(1, 3, size.toLong(), size.toLong())).use { t ->
            det.run(mapOf(det.inputNames.first() to t)).use { res ->
                val strides = intArrayOf(8, 16, 32)
                for ((idx, stride) in strides.withIndex()) {
                    val scores = (res[idx] as OnnxTensor).toArray()
                    val boxes = (res[idx + 3] as OnnxTensor).toArray()
                    val kp = (res[idx + 6] as OnnxTensor).toArray()
                    val g = size / stride
                    for (k in 0 until g * g * 2) {
                        if (scores[k] < 0.5f) continue
                        val a = k / 2
                        val cx = ((a % g) * stride).toFloat()
                        val cy = ((a / g) * stride).toFloat()
                        val pts = FloatArray(10)
                        for (j in 0 until 5) {
                            pts[2 * j] = (cx + kp[10 * k + 2 * j] * stride) / ratio
                            pts[2 * j + 1] = (cy + kp[10 * k + 2 * j + 1] * stride) / ratio
                        }
                        found.add(
                            Face(
                                (cx - boxes[4 * k] * stride) / ratio,
                                (cy - boxes[4 * k + 1] * stride) / ratio,
                                (cx + boxes[4 * k + 2] * stride) / ratio,
                                (cy + boxes[4 * k + 3] * stride) / ratio,
                                scores[k], pts
                            )
                        )
                    }
                }
            }
        }
        return nms(found)
    }

    private fun iou(a: Face, b: Face): Float {
        val ix = max(0f, min(a.x2, b.x2) - max(a.x1, b.x1))
        val iy = max(0f, min(a.y2, b.y2) - max(a.y1, b.y1))
        val i = ix * iy
        return i / (a.area + b.area - i + 1e-6f)
    }

    private fun nms(all: List<Face>): List<Face> {
        val keep = ArrayList<Face>()
        for (c in all.sortedByDescending { it.score }) {
            if (keep.none { iou(it, c) > 0.4f }) keep.add(c)
        }
        return keep
    }

    // ---------------- robuste Erkennung ----------------
    /** true, wenn das Erkennungsmodell nur eine feste Eingabegröße kann (dann Kachel-Verfahren). */
    private val detFixed: Boolean by lazy {
        try {
            val s = (det.inputInfo[det.inputNames.first()]?.info as? TensorInfo)?.shape
            s != null && s.size >= 4 && s[2] > 0 && s[3] > 0
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Erst normal, bei leerem Ergebnis in doppelter Auflösung, dann horizontal gespiegelt.
     * Alle Boxen und Punkte kommen in Koordinaten des Originalbilds zurück.
     */
    fun detectRobust(bmp: Bitmap): List<Face> {
        val a = detect(bmp)
        if (a.isNotEmpty()) return a
        val b = detectFine(bmp)
        if (b.isNotEmpty()) return b
        return detectMirrored(bmp)
    }

    /** "2x hochskaliert": Netz-Eingabe 1280 statt 640 (ohne riesiges Zwischenbild); sonst überlappende Kacheln. */
    private fun detectFine(bmp: Bitmap): List<Face> {
        if (!detFixed) {
            try {
                return detect(bmp, 1280)
            } catch (e: Throwable) {
                // z. B. zu wenig Speicher: weiter mit Kacheln
            }
        }
        return detectTiles(bmp)
    }

    private fun detectTiles(bmp: Bitmap): List<Face> {
        val tw = max(32, (bmp.width * 0.55f).toInt()).coerceAtMost(bmp.width)
        val th = max(32, (bmp.height * 0.55f).toInt()).coerceAtMost(bmp.height)
        val xs = if (tw >= bmp.width) intArrayOf(0) else intArrayOf(0, bmp.width - tw)
        val ys = if (th >= bmp.height) intArrayOf(0) else intArrayOf(0, bmp.height - th)
        val all = ArrayList<Face>()
        for (ty in ys) for (tx in xs) {
            val tile = Bitmap.createBitmap(bmp, tx, ty, tw, th)
            for (f in detect(tile)) {
                val k = FloatArray(10) { if (it % 2 == 0) f.kps[it] + tx else f.kps[it] + ty }
                all.add(Face(f.x1 + tx, f.y1 + ty, f.x2 + tx, f.y2 + ty, f.score, k))
            }
            if (tile !== bmp) tile.recycle()
        }
        return nms(all)
    }

    /** Gespiegelt suchen und zurückrechnen; linker/rechter Augen- und Mundpunkt werden dabei vertauscht. */
    private fun detectMirrored(bmp: Bitmap): List<Face> {
        val w = bmp.width.toFloat()
        val flip = Matrix().apply { preScale(-1f, 1f) }
        val mirrored = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, flip, true)
        val found = try { detect(mirrored) } finally { if (mirrored !== bmp) mirrored.recycle() }
        return found.map { f ->
            val k = FloatArray(10)
            for (j in 0 until 5) {
                val src = when (j) { 0 -> 1; 1 -> 0; 3 -> 4; 4 -> 3; else -> j }
                k[2 * j] = w - f.kps[2 * src]
                k[2 * j + 1] = f.kps[2 * src + 1]
            }
            Face(w - f.x2, f.y1, w - f.x1, f.y2, f.score, k)
        }
    }

    // ---------------- Quellgesicht ----------------
    fun embed(bmp: Bitmap, f: Face): FloatArray {
        val (crop, _) = alignTo(bmp, f.kps, dst112, 112)
        val data = chw(crop, 127.5f, 127.5f)
        return tensor(data, longArrayOf(1, 3, 112, 112)).use { t ->
            rec.run(mapOf(rec.inputNames.first() to t)).use { r ->
                normalize((r[0] as OnnxTensor).toArray())
            }
        }
    }

    /** Kosinus-Ähnlichkeit zweier (bereits normalisierter) Embeddings: 1.0 = gleich. */
    fun cosine(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) s += a[i] * b[i]
        return s
    }

    /** Mittelt mehrere Fotos zu EINEM Quellgesicht und rechnet es für InSwapper um. */
    fun makeLatent(embs: List<FloatArray>): FloatArray {
        val avg = FloatArray(512)
        for (e in embs) for (i in 0 until 512) avg[i] += e[i]
        val m = normalize(avg)
        val out = FloatArray(512)
        for (i in 0 until 512) {
            val v = m[i]
            val row = i * 512
            for (j in 0 until 512) out[j] += v * emap[row + j]
        }
        return normalize(out)
    }

    // ---------------- Verdeckungs-Maske (XSeg) ----------------
    private fun blur5(src: FloatArray, w: Int, h: Int): FloatArray {
        val r = 15
        val k = FloatArray(2 * r + 1)
        var sum = 0f
        for (i in -r..r) { k[i + r] = exp(-(i * i) / 50f); sum += k[i + r] }
        for (i in k.indices) k[i] /= sum
        val tmp = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (i in -r..r) s += src[y * w + (x + i).coerceIn(0, w - 1)] * k[i + r]
            tmp[y * w + x] = s
        }
        val out = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (i in -r..r) s += tmp[(y + i).coerceIn(0, h - 1) * w + x] * k[i + r]
            out[y * w + x] = s
        }
        return out
    }

    /** 128x128-Maske: 1 = Gesicht (tauschen), 0 = verdeckt (Original behalten). */
    private fun occlusionMask(crop: Bitmap): FloatArray? {
        val s = occ ?: return null
        return try { occlusionMaskRun(s, crop) } catch (e: Throwable) { null }
    }

    private fun occlusionMaskRun(s: OrtSession, crop: Bitmap): FloatArray? {
        val big = Bitmap.createScaledBitmap(crop, 256, 256, true)
        val px = IntArray(256 * 256)
        big.getPixels(px, 0, 256, 0, 0, 256, 256)
        val data = FloatArray(256 * 256 * 3)
        for (i in px.indices) {            // FaceFusion füttert XSeg in BGR-Reihenfolge, NHWC, 0..1
            val c = px[i]
            data[i * 3] = (c and 255) / 255f
            data[i * 3 + 1] = ((c shr 8) and 255) / 255f
            data[i * 3 + 2] = ((c shr 16) and 255) / 255f
        }
        val out = tensor(data, longArrayOf(1, 256, 256, 3)).use { t ->
            s.run(mapOf(s.inputNames.first() to t)).use { r -> (r[0] as OnnxTensor).toArray() }
        }
        if (out.size != 256 * 256) return null
        val m = FloatArray(128 * 128)
        for (y in 0 until 128) for (x in 0 until 128) {
            val a = out[(2 * y) * 256 + 2 * x].coerceIn(0f, 1f)
            val b = out[(2 * y) * 256 + 2 * x + 1].coerceIn(0f, 1f)
            val c = out[(2 * y + 1) * 256 + 2 * x].coerceIn(0f, 1f)
            val d = out[(2 * y + 1) * 256 + 2 * x + 1].coerceIn(0f, 1f)
            m[y * 128 + x] = (a + b + c + d) / 4f
        }
        val bl = blur5(m, 128, 128)
        for (i in bl.indices) bl[i] = (bl[i].coerceIn(0.5f, 1f) - 0.5f) * 2f
        return bl
    }

    // ---------------- Tausch ----------------
    /**
     * colorMatch 0..1: Farb-/Helligkeitsanpassung des neuen Gesichts an das Original.
     * useOcc: Brillen, Hände, Mikrofone usw. vor dem Gesicht bleiben erhalten (braucht xseg_1.onnx).
     */
    fun swap(target: Bitmap, f: Face, latent: FloatArray, colorMatch: Float, useOcc: Boolean): Bitmap {
        if (min(f.x2 - f.x1, f.y2 - f.y1) < 48f) {
            val r = try { swapSmall(target, f, latent, colorMatch, useOcc) } catch (e: Exception) { null }
            if (r != null) return r
        }
        val (layer, inv) = faceLayer(target, f.kps, latent, colorMatch, useOcc) ?: return target
        val result = target.copy(Bitmap.Config.ARGB_8888, true)
        Canvas(result).drawBitmap(layer, inv, Paint(Paint.FILTER_BITMAP_FLAG))
        return result
    }

    /**
     * Kleine Gesichter (kürzere Boxseite < 48 px): Ausschnitt samt 20 % Rand bikubisch vergrößern,
     * dort tauschen und nur die Gesichtsebene zurück ins Originalbild projizieren.
     */
    private fun swapSmall(target: Bitmap, f: Face, latent: FloatArray, colorMatch: Float, useOcc: Boolean): Bitmap? {
        val inv0 = Matrix()
        if (!similarity(f.kps, dst128).invert(inv0)) return null
        // Fußabdruck des 128-px-Ausschnitts im Zielbild
        val c = floatArrayOf(0f, 0f, 128f, 0f, 128f, 128f, 0f, 128f)
        inv0.mapPoints(c)
        var minX = c[0]; var maxX = c[0]; var minY = c[1]; var maxY = c[1]
        for (i in 1 until 4) {
            minX = min(minX, c[2 * i]); maxX = max(maxX, c[2 * i])
            minY = min(minY, c[2 * i + 1]); maxY = max(maxY, c[2 * i + 1])
        }
        val cx = (minX + maxX) / 2f
        val cy = (minY + maxY) / 2f
        val hw = (maxX - minX) / 2f * 1.2f
        val hh = (maxY - minY) / 2f * 1.2f
        val l = floor(cx - hw).toInt().coerceIn(0, target.width - 1)
        val t = floor(cy - hh).toInt().coerceIn(0, target.height - 1)
        val r = ceil(cx + hw).toInt().coerceIn(l + 1, target.width)
        val b = ceil(cy + hh).toInt().coerceIn(t + 1, target.height)
        val pw = r - l
        val ph = b - t
        if (pw < 8 || ph < 8) return null

        val minSide = max(8f, min(f.x2 - f.x1, f.y2 - f.y1))
        val k = min((96f / minSide).coerceIn(1.5f, 4f), 640f / max(pw, ph))
        if (k < 1.2f) return null
        val uw = max(1, (pw * k).toInt())
        val uh = max(1, (ph * k).toInt())
        val sx = uw / pw.toFloat()
        val sy = uh / ph.toFloat()

        val patch = Bitmap.createBitmap(target, l, t, pw, ph)
        val up = bicubicScale(patch, uw, uh)
        if (patch !== target) patch.recycle()
        val kp = FloatArray(10) { if (it % 2 == 0) (f.kps[it] - l) * sx else (f.kps[it] - t) * sy }
        val layerPair = try {
            faceLayer(up, kp, latent, colorMatch, useOcc)
        } finally {
            up.recycle()
        }
        val (layer, invUp) = layerPair ?: return null

        // Gesichtsebene -> vergrößerter Ausschnitt -> Originalbild
        val toOrig = Matrix(invUp)
        toOrig.postScale(1f / sx, 1f / sy)
        toOrig.postTranslate(l.toFloat(), t.toFloat())
        val result = target.copy(Bitmap.Config.ARGB_8888, true)
        Canvas(result).drawBitmap(layer, toOrig, Paint(Paint.FILTER_BITMAP_FLAG))
        return result
    }

    private fun cubicW(t: Float): Float {
        val x = abs(t)
        return when {
            x < 1f -> 1.5f * x * x * x - 2.5f * x * x + 1f
            x < 2f -> -0.5f * x * x * x + 2.5f * x * x - 4f * x + 2f
            else -> 0f
        }
    }

    /** Bikubische Vergrößerung (Catmull-Rom) für kleine Ausschnitte. */
    private fun bicubicScale(src: Bitmap, nw: Int, nh: Int): Bitmap {
        val sw = src.width
        val sh = src.height
        val px = IntArray(sw * sh)
        src.getPixels(px, 0, sw, 0, 0, sw, sh)

        fun table(n: Int, s: Int): Pair<IntArray, FloatArray> {
            val idx = IntArray(n * 4)
            val wt = FloatArray(n * 4)
            val ratio = s.toFloat() / n
            for (o in 0 until n) {
                val c = (o + 0.5f) * ratio - 0.5f
                val base = floor(c).toInt()
                var sum = 0f
                for (j in 0 until 4) {
                    val p = base - 1 + j
                    idx[o * 4 + j] = p.coerceIn(0, s - 1)
                    val w = cubicW(c - p)
                    wt[o * 4 + j] = w
                    sum += w
                }
                for (j in 0 until 4) wt[o * 4 + j] /= sum
            }
            return Pair(idx, wt)
        }

        val (xi, xw) = table(nw, sw)
        val (yi, yw) = table(nh, sh)
        val tmp = FloatArray(nw * sh * 3)
        for (y in 0 until sh) for (x in 0 until nw) {
            var r = 0f; var g = 0f; var b = 0f
            for (j in 0 until 4) {
                val c = px[y * sw + xi[x * 4 + j]]
                val w = xw[x * 4 + j]
                r += ((c shr 16) and 255) * w
                g += ((c shr 8) and 255) * w
                b += (c and 255) * w
            }
            val o = (y * nw + x) * 3
            tmp[o] = r; tmp[o + 1] = g; tmp[o + 2] = b
        }
        val out = IntArray(nw * nh)
        for (y in 0 until nh) for (x in 0 until nw) {
            var r = 0f; var g = 0f; var b = 0f
            for (j in 0 until 4) {
                val o = (yi[y * 4 + j] * nw + x) * 3
                val w = yw[y * 4 + j]
                r += tmp[o] * w
                g += tmp[o + 1] * w
                b += tmp[o + 2] * w
            }
            val ri = (r + 0.5f).toInt().coerceIn(0, 255)
            val gi = (g + 0.5f).toInt().coerceIn(0, 255)
            val bi = (b + 0.5f).toInt().coerceIn(0, 255)
            out[y * nw + x] = (255 shl 24) or (ri shl 16) or (gi shl 8) or bi
        }
        val res = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888)
        res.setPixels(out, 0, nw, 0, 0, nw, nh)
        return res
    }

    /** 128x128-Gesichtsebene (mit Alpha) und Matrix Ausschnitt -> Quellbild; null bei Fehler. */
    private fun faceLayer(
        src: Bitmap, kps: FloatArray, latent: FloatArray, colorMatch: Float, useOcc: Boolean
    ): Pair<Bitmap, Matrix>? {
        val (crop, m) = alignTo(src, kps, dst128, 128)
        val inv = Matrix()
        if (!m.invert(inv)) return null

        val input = chw(crop, 0f, 255f)
        val fake = tensor(input, longArrayOf(1, 3, 128, 128)).use { t ->
            tensor(latent, longArrayOf(1, 512)).use { s ->
                swp.run(mapOf("target" to t, "source" to s)).use { r ->
                    (r[0] as OnnxTensor).toArray()
                }
            }
        }

        val plane = 128 * 128
        val faceA = FloatArray(plane)
        for (y in 0 until 128) for (x in 0 until 128) {
            val dx = (x - 64f) / 54f
            val dy = (y - 72f) / 56f
            faceA[y * 128 + x] = ((1f - sqrt(dx * dx + dy * dy)) / 0.3f).coerceIn(0f, 1f)
        }
        val occM = if (useOcc) occlusionMask(crop) else null

        // Farb- und Helligkeitsanpassung (Mittelwert und Streuung je Farbkanal im Kerngesicht)
        val col = FloatArray(plane * 3)
        for (i in col.indices) col[i] = fake[i]
        if (colorMatch > 0f) {
            for (c in 0 until 3) {
                var n = 0; var mt = 0.0; var mf = 0.0
                for (i in 0 until plane) if (faceA[i] > 0.9f) { n++; mt += input[c * plane + i]; mf += fake[c * plane + i] }
                if (n < 50) continue
                mt /= n; mf /= n
                var vt = 0.0; var vf = 0.0
                for (i in 0 until plane) if (faceA[i] > 0.9f) {
                    val a = input[c * plane + i] - mt; val b = fake[c * plane + i] - mf
                    vt += a * a; vf += b * b
                }
                val k = (sqrt(vt / n) / (sqrt(vf / n) + 1e-6)).coerceIn(0.7, 1.4)
                for (i in 0 until plane) {
                    val v = fake[c * plane + i]
                    val adj = ((v - mf) * k + mt).toFloat()
                    col[c * plane + i] = (v + (adj - v) * colorMatch).coerceIn(0f, 1f)
                }
            }
        }

        val px = IntArray(plane)
        for (i in 0 until plane) {
            val r = (col[i] * 255f).coerceIn(0f, 255f).toInt()
            val g = (col[plane + i] * 255f).coerceIn(0f, 255f).toInt()
            val b = (col[2 * plane + i] * 255f).coerceIn(0f, 255f).toInt()
            val a = faceA[i] * (occM?.get(i) ?: 1f)
            px[i] = ((a * 255f).toInt() shl 24) or (r shl 16) or (g shl 8) or b
        }
        val fb = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
        fb.setPixels(px, 0, 128, 0, 0, 128, 128)
        return Pair(fb, inv)
    }

    // ---------------- Verbesserer (GFPGAN 1.4 / CodeFormer) ----------------
    fun enhance(bmp: Bitmap, f: Face, modelName: String, strength: Float): Bitmap {
        val sess = enhancers.getOrPut(modelName) { open(modelName) }
        val (crop, m) = alignTo(bmp, f.kps, dst512, 512)
        val inv = Matrix()
        if (!m.invert(inv)) return bmp

        val data = chw(crop, 127.5f, 127.5f)
        val tImg = tensor(data, longArrayOf(1, 3, 512, 512))
        var tW: OnnxTensor? = null
        val out: FloatArray = try {
            val inputs = HashMap<String, OnnxTensor>()
            for (n in sess.inputNames) {
                if (n == "weight") {
                    val w = OnnxTensor.createTensor(env, DoubleBuffer.wrap(doubleArrayOf(1.0)), longArrayOf(1))
                    tW = w
                    inputs[n] = w
                } else {
                    inputs[n] = tImg
                }
            }
            sess.run(inputs).use { r -> (r[0] as OnnxTensor).toArray() }
        } finally {
            tImg.close()
            tW?.close()
        }

        val plane = 512 * 512
        val px = IntArray(plane)
        for (y in 0 until 512) for (x in 0 until 512) {
            val i = y * 512 + x
            val r = (((out[i].coerceIn(-1f, 1f) + 1f) / 2f) * 255f + 0.5f).toInt()
            val g = (((out[plane + i].coerceIn(-1f, 1f) + 1f) / 2f) * 255f + 0.5f).toInt()
            val b = (((out[2 * plane + i].coerceIn(-1f, 1f) + 1f) / 2f) * 255f + 0.5f).toInt()
            val d = min(min(x, y), min(511 - x, 511 - y)).toFloat()
            val a = ((d - 40f) / 72f).coerceIn(0f, 1f) * strength
            px[i] = ((a * 255f).toInt() shl 24) or (r shl 16) or (g shl 8) or b
        }
        val eb = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
        eb.setPixels(px, 0, 512, 0, 0, 512, 512)

        val result = bmp.copy(Bitmap.Config.ARGB_8888, true)
        Canvas(result).drawBitmap(eb, inv, Paint(Paint.FILTER_BITMAP_FLAG))
        return result
    }
}
