package com.mashaswape

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max

/**
 * Zeigt das Bild mit nummerierten Rahmen. Antippen schaltet ein Gesicht durch:
 * aus (rot) -> Person 1 -> Person 2 ... -> aus. Jede Person hat eine eigene Farbe.
 */
class FacePickView(
    ctx: Context, private val bmp: Bitmap, private val faces: List<Face>, private val names: List<String>
) : View(ctx) {
    val assign = IntArray(faces.size) { if (it == 0) 0 else -1 }
    private var scale = 1f
    private val palette = intArrayOf(
        Color.rgb(0, 200, 90), Color.rgb(60, 150, 255), Color.rgb(255, 170, 0),
        Color.rgb(200, 80, 255), Color.rgb(0, 210, 210)
    )
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 40f; isFakeBoldText = true
    }
    private var downX = 0f
    private var downY = 0f

    fun assignAll() {
        for (i in assign.indices) assign[i] = 0
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val ww = MeasureSpec.getSize(w).let { if (it <= 0) 800 else it }
        scale = ww.toFloat() / bmp.width
        setMeasuredDimension(ww, max(1, (bmp.height * scale).toInt()))
    }

    override fun onDraw(c: Canvas) {
        c.drawBitmap(bmp, null, RectF(0f, 0f, bmp.width * scale, bmp.height * scale), null)
        for ((i, f) in faces.withIndex()) {
            val a = assign[i]
            val col = if (a < 0) Color.rgb(230, 60, 60) else palette[a % palette.size]
            boxPaint.color = col
            fillPaint.color = col
            val r = RectF(f.x1 * scale, f.y1 * scale, f.x2 * scale, f.y2 * scale)
            c.drawRect(r, boxPaint)
            val label = "${i + 1}" + if (a >= 0 && names.size > 1) " " + names[a].take(8) else ""
            val tw = textPaint.measureText(label) + 24f
            c.drawRect(r.left, r.top, r.left + tw, r.top + 52f, fillPaint)
            c.drawText(label, r.left + 12f, r.top + 40f, textPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
            }
            MotionEvent.ACTION_UP -> {
                if (abs(e.x - downX) < 20f && abs(e.y - downY) < 20f) {
                    val bx = e.x / scale
                    val by = e.y / scale
                    var best = -1
                    var bestArea = Float.MAX_VALUE
                    for ((i, f) in faces.withIndex()) {
                        if (bx >= f.x1 && bx <= f.x2 && by >= f.y1 && by <= f.y2 && f.area < bestArea) {
                            best = i
                            bestArea = f.area
                        }
                    }
                    if (best >= 0) {
                        val n = max(1, names.size)
                        assign[best] = if (assign[best] + 1 >= n) -1 else assign[best] + 1
                        invalidate()
                    }
                }
            }
        }
        return true
    }
}
