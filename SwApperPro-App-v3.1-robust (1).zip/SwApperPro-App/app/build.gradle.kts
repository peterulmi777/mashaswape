plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mashaswape"
    compileSdk = 34

    // Fester Schlüssel: dadurch lassen sich spätere Versionen OHNE Deinstallieren
    // über die alte App installieren (Modelle bleiben erhalten).
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storeType = "pkcs12"
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    defaultConfig {
        applicationId = "com.swapperpro.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 6
        versionName = "3.1"
        ndk { abiFilters.add("arm64-v8a") }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.18.0")
}
