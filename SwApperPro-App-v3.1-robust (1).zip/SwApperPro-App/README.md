# *#SwAppEr.PrO#* v3.1 – Face-Swap-App für Android (offline, dunkles Design)

Neu in v3.1 (Robustheit):
- Erkennung mehrstufig: normal, dann doppelte Auflösung, dann gespiegelt
- Nachverfolgung toleranter (SAD-Schwelle 45), bei Unsicherheit wird der letzte Stand eingefroren
- Personen-Zuordnung: Schwelle 0.25, jedes Gesicht und jede Referenz höchstens einmal pro Bild
- Verdeckungs-Schutz standardmäßig an (ohne xseg_1.onnx wird er übersprungen)
- Farbanpassung Standard 45 %
- Verbesserer (GFPGAN/CodeFormer) auch im Video: jedes 3. Bild und bei Gesichtern unter 96 px
- Kleine Gesichter (unter 48 px): Ausschnitt vergrößert, getauscht und sauber zurückprojiziert

Neu in v3.0:
- Turbo-Leistungsmodus (mehr Rechenkerne, optional NNAPI), Voreinstellungen Schnell / Ausgewogen / Beste Qualität
- Videos laufen als Projekte im Hintergrund (Benachrichtigung), in Teilstücken, mit Pause, Stopp und Fortsetzen nach Abbruch
- Gesichtssuche nur in jedem 2. oder 3. Bild plus Nachverfolgung
- Verdeckungs-Schutz (XSeg): Hände, Brillen, Instrumente bleiben vor dem Gesicht
- Farb- und Helligkeitsanpassung des getauschten Gesichts
- Testbild vor dem Start
- Quellpersonen speichern; mehrere Personen im Ziel zuordnen (Antippen wechselt die Person)
- Beim Modell-Import: Speicherprüfung, halbe Dateien werden gelöscht

Modelle (Schritt 1 in der App):
Pflicht: det_10g.onnx, w600k_r50.onnx, inswapper_128.onnx, emap.bin
Optional: gfpgan_1.4.onnx, codeformer.onnx, xseg_1.onnx
  https://huggingface.co/facefusion/models-3.1.0/resolve/main/xseg_1.onnx  (ca. 70 MB)

Nur mit ausdrücklicher Einwilligung der abgebildeten Personen verwenden.
