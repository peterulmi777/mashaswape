#!/usr/bin/env python3
"""Bereitet die KI-Modelle für die Mashaswape-App vor (einmal am PC, mit Internet).

Ergebnis: Ordner ~/mashaswape-models mit
  det_10g.onnx, w600k_r50.onnx, inswapper_128.onnx, emap.bin
Diese 4 Dateien kopierst du aufs Handy und importierst sie in der App.
"""
import os
import shutil
import sys
import urllib.request
import zipfile

import numpy as np
import onnx
from onnx import numpy_helper

OUT = os.path.expanduser("~/mashaswape-models")
os.makedirs(OUT, exist_ok=True)

BUFFALO = "https://github.com/deepinsight/insightface/releases/download/v0.7/buffalo_l.zip"
SWAPPER = "https://huggingface.co/ezioruan/inswapper_128.onnx/resolve/main/inswapper_128.onnx"


def download(url, dest):
    print("Lade", url)

    def hook(block, size, total):
        if total > 0:
            sys.stdout.write("\r  %3d%%" % min(100, block * size * 100 // total))
            sys.stdout.flush()

    urllib.request.urlretrieve(url, dest + ".part", hook)
    os.replace(dest + ".part", dest)
    print()


def have(name):
    p = os.path.join(OUT, name)
    return os.path.exists(p) and os.path.getsize(p) > 1_000_000


# --- Erkennung + Embedding (buffalo_l) ---
if not (have("det_10g.onnx") and have("w600k_r50.onnx")):
    local = os.path.expanduser("~/.insightface/models/buffalo_l")
    if os.path.exists(os.path.join(local, "det_10g.onnx")):
        for n in ("det_10g.onnx", "w600k_r50.onnx"):
            shutil.copy(os.path.join(local, n), os.path.join(OUT, n))
    else:
        z = os.path.join(OUT, "buffalo_l.zip")
        download(BUFFALO, z)
        with zipfile.ZipFile(z) as zf:
            for n in ("det_10g.onnx", "w600k_r50.onnx"):
                with zf.open(n) as src, open(os.path.join(OUT, n), "wb") as dst:
                    shutil.copyfileobj(src, dst)
        os.remove(z)

# --- Swapper ---
swapper = os.path.join(OUT, "inswapper_128.onnx")
if not have("inswapper_128.onnx"):
    old = "/opt/faceswap-toolkit/models/inswapper_128.onnx"
    if os.path.exists(old):
        shutil.copy(old, swapper)
    else:
        download(SWAPPER, swapper)

# --- emap (Embedding-Matrix aus dem Swapper-Modell) ---
print("Extrahiere emap.bin ...")
model = onnx.load(swapper)
emap = numpy_helper.to_array(model.graph.initializer[-1])
assert emap.shape == (512, 512), "Unerwartete emap-Form: %s" % (emap.shape,)
emap.astype("<f4").tofile(os.path.join(OUT, "emap.bin"))

print("\nFertig. Diese Dateien aufs Handy kopieren:")
for n in ("det_10g.onnx", "w600k_r50.onnx", "inswapper_128.onnx", "emap.bin"):
    p = os.path.join(OUT, n)
    print("  %-22s %7.1f MB" % (n, os.path.getsize(p) / 1e6))
print("Ordner:", OUT)
