package com.mashaswape

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private lateinit var consent: CheckBox
    private lateinit var allFaces: CheckBox

    private val modelDir by lazy { File(filesDir, "models").apply { mkdirs() } }
    private val needed = listOf("det_10g.onnx", "w600k_r50.onnx", "inswapper_128.onnx", "emap.bin")
    private var sources = listOf<Uri>()
    private var targets = listOf<Uri>()
    private var engine: FaceEngine? = null
    @Volatile private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        root.addView(TextView(this).apply { text = "🍒 Mashaswape 🍓"; textSize = 22f })
        status = TextView(this).apply { setPadding(0, 16, 0, 16) }
        root.addView(status)

        consent = CheckBox(this).apply {
            text = "Ich nutze das nur mit ausdrücklicher Einwilligung der abgebildeten Personen. " +
                "Keine Täuschung, keine Rufschädigung, keine Veröffentlichung ohne Erlaubnis."
        }
        root.addView(consent)

        root.addView(button("1. Modelle importieren (4 Dateien)") { pick(1, "*/*", true) })
        root.addView(button("2. Quellfotos wählen (mehrere, eine Person)") { pick(2, "image/*", true) })
        root.addView(button("3. Zielfotos wählen (ein oder mehrere)") { pick(3, "image/*", true) })
        allFaces = CheckBox(this).apply { text = "Alle Gesichter im Zielbild tauschen (sonst nur das größte)" }
        root.addView(allFaces)
        root.addView(button("TAUSCHEN") { runSwap() })

        preview = ImageView(this).apply {
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        root.addView(preview)
        setContentView(ScrollView(this).apply { addView(root) })
        say(modelStatus())
    }

    private fun button(label: String, onClick: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { onClick() } }

    private fun say(s: String) = runOnUiThread { status.text = s }

    private fun modelStatus(): String {
        val missing = needed.filter { !File(modelDir, it).exists() }
        return if (missing.isEmpty()) "Modelle vorhanden. Quellfotos und Ziel wählen."
        else "Fehlende Modelle: ${missing.joinToString(", ")}"
    }

    private fun pick(req: Int, mime: String, multi: Boolean) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multi)
        }
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        when (req) {
            1 -> importModels(uris)
            2 -> { sources = uris; say("${uris.size} Quellfoto(s) gewählt.") }
            3 -> { targets = uris; say("${uris.size} Zielfoto(s) gewählt.") }
        }
    }

    private fun displayName(u: Uri): String? =
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }

    private fun importModels(uris: List<Uri>) {
        Thread {
            try {
                for (u in uris) {
                    val name = displayName(u) ?: continue
                    if (name !in needed) { say("Übersprungen: $name"); continue }
                    say("Kopiere $name ...")
                    contentResolver.openInputStream(u)?.use { inp ->
                        File(modelDir, name).outputStream().use { out -> inp.copyTo(out) }
                    }
                }
                engine = null
                say(modelStatus())
            } catch (e: Throwable) {
                say("Fehler beim Import: ${e.message}")
            }
        }.start()
    }

    private fun load(u: Uri): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > 2400) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: return null
        val orient = contentResolver.openInputStream(u)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
        } ?: 1
        val deg = when (orient) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        if (deg == 0f) return bmp
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun save(b: Bitmap, n: Int) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "mashaswape_${System.currentTimeMillis()}_$n.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Mashaswape")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
        contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    }

    private fun runSwap() {
        if (busy) return
        if (!consent.isChecked) { say("Bitte zuerst die Einwilligung bestätigen."); return }
        if (sources.isEmpty() || targets.isEmpty()) { say("Bitte Quellfotos und Zielfotos wählen."); return }
        val missing = needed.filter { !File(modelDir, it).exists() }
        if (missing.isNotEmpty()) { say("Fehlende Modelle: ${missing.joinToString(", ")}"); return }

        busy = true
        Thread {
            try {
                say("Lade Modelle (beim ersten Mal dauert das) ...")
                val eng = engine ?: FaceEngine(modelDir).also { engine = it }

                val embs = ArrayList<FloatArray>()
                for ((i, u) in sources.withIndex()) {
                    say("Quellgesicht ${i + 1}/${sources.size} ...")
                    val b = load(u) ?: continue
                    val f = eng.detect(b).maxByOrNull { it.area } ?: continue
                    embs.add(eng.embed(b, f))
                }
                if (embs.isEmpty()) { say("In den Quellfotos wurde kein Gesicht gefunden."); return@Thread }
                val latent = eng.makeLatent(embs)

                var last: Bitmap? = null
                var done = 0
                for ((i, u) in targets.withIndex()) {
                    say("Ziel ${i + 1}/${targets.size} wird getauscht ...")
                    val b = load(u) ?: continue
                    var faces = eng.detect(b).sortedByDescending { it.area }
                    if (faces.isEmpty()) continue
                    if (!allFaces.isChecked) faces = faces.take(1)
                    var res = b
                    for (f in faces) res = eng.swap(res, f, latent)
                    save(res, i)
                    last = res
                    done++
                }
                val shown = last
                if (shown != null) runOnUiThread { preview.setImageBitmap(shown) }
                say("Fertig: $done von ${targets.size} Bild(ern) gespeichert in Bilder/Mashaswape.")
            } catch (e: Throwable) {
                say("Fehler: ${e.message}")
            } finally {
                busy = false
            }
        }.start()
    }
}
