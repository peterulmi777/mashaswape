# Mashaswape – Face-Swap-App für Android (offline)

## A) Modelle vorbereiten (einmal, am Linux-PC, mit Internet)
    python3 -m venv ~/mm-venv
    ~/mm-venv/bin/pip install onnx numpy
    ~/mm-venv/bin/python prepare_models.py
-> Ordner ~/mashaswape-models (4 Dateien, ca. 850 MB) per USB aufs Handy kopieren.

## B) APK kostenlos online bauen (GitHub Actions)
1. Kostenloses Konto auf github.com, "New repository" (z. B. "mashaswape"), privat ist ok.
2. "uploading an existing file" wählen und den INHALT dieses Ordners (inkl. versteckter Ordner .github)
   per Drag & Drop in den Browser ziehen, dann "Commit changes".
3. Reiter "Actions" -> "Build APK" -> "Run workflow". Nach ca. 5-10 Minuten ist der Lauf grün.
4. Lauf öffnen -> unten "Artifacts" -> "Mashaswape-APK" herunterladen (ZIP, darin die APK).

## C) Auf dem Handy
1. APK installieren (Android fragt nach "Installation aus unbekannten Quellen" erlauben).
2. App öffnen -> "Modelle importieren" -> die 4 Dateien wählen (kann kurz dauern).
3. Quellfotos (mehrere Fotos EINER Person), Zielfotos wählen, Einwilligung bestätigen, TAUSCHEN.
4. Ergebnisse liegen in Bilder/Mashaswape.

Nur mit ausdrücklicher Einwilligung der abgebildeten Personen verwenden.
Die Modelle (insightface/InSwapper) sind nur für nicht-kommerzielle Nutzung lizenziert.
