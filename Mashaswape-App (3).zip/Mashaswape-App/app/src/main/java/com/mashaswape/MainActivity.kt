package com.mashaswape

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.io.File
import java.util.concurrent.CountDownLatch
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private lateinit var consent: CheckBox
    private lateinit var askFaces: CheckBox
    private lateinit var allFaces: CheckBox
    private lateinit var enhSpinner: Spinner
    private lateinit var strengthEdit: EditText
    private lateinit var secEdit: EditText
    private lateinit var fpsEdit: EditText

    private val modelDir by lazy { File(filesDir, "models").apply { mkdirs() } }
    private val needed = listOf("det_10g.onnx", "w600k_r50.onnx", "inswapper_128.onnx", "emap.bin")
    private val optional = listOf("gfpgan_1.4.onnx", "codeformer.onnx")
    private var sources = listOf<Uri>()
    private var targets = listOf<Uri>()
    private var engine: FaceEngine? = null
    @Volatile private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            keepScreenOn = true
        }
        root.addView(TextView(this).apply { text = "🍒 Mashaswape 🍓"; textSize = 22f })
        status = TextView(this).apply { setPadding(0, 16, 0, 16) }
        root.addView(status)

        consent = CheckBox(this).apply {
            text = "Ich nutze das nur mit ausdrücklicher Einwilligung der abgebildeten Personen. " +
                "Keine Täuschung, keine Rufschädigung, keine Veröffentlichung ohne Erlaubnis."
        }
        root.addView(consent)

        root.addView(button("1. Modelle importieren (4 Pflicht + Verbesserer)") { pick(1, "*/*", true, null) })
        root.addView(button("2. Quellfotos wählen (mehrere, eine Person)") { pick(2, "image/*", true, null) })
        root.addView(button("3. Ziel wählen: Fotos und/oder Videos") {
            pick(3, "*/*", true, arrayOf("image/*", "video/*"))
        })

        askFaces = CheckBox(this).apply {
            text = "Bei Fotos vorher fragen, welche Gesichter getauscht werden"
            isChecked = true
        }
        root.addView(askFaces)
        allFaces = CheckBox(this).apply {
            text = "Ohne Rückfrage / bei Videos: alle Gesichter tauschen (sonst nur das größte)"
        }
        root.addView(allFaces)

        root.addView(TextView(this).apply { text = "Gesichts-Verbesserer (nur Fotos):"; setPadding(0, 16, 0, 0) })
        enhSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Aus", "GFPGAN 1.4", "CodeFormer", "Beide (zwei Bilder zum Vergleichen)")
            )
        }
        root.addView(enhSpinner)
        root.addView(TextView(this).apply { text = "Stärke des Verbesserers in % (Standard 80)" })
        strengthEdit = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("80") }
        root.addView(strengthEdit)

        root.addView(TextView(this).apply { text = "Video: maximale Länge in Sekunden"; setPadding(0, 16, 0, 0) })
        secEdit = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("5") }
        root.addView(secEdit)
        root.addView(TextView(this).apply { text = "Video: Bilder pro Sekunde (5 bis 30, weniger = schneller)" })
        fpsEdit = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("10") }
        root.addView(fpsEdit)

        root.addView(button("TAUSCHEN") { runSwap() })

        preview = ImageView(this).apply {
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        root.addView(preview)
        setContentView(ScrollView(this).apply { addView(root) })
        say(modelStatus())
    }

    private fun button(label: String, onClick: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { onClick() } }

    private fun say(s: String) = runOnUiThread { status.text = s }

    private fun modelStatus(): String {
        val missing = needed.filter { !File(modelDir, it).exists() }
        if (missing.isNotEmpty()) return "Fehlende Modelle: ${missing.joinToString(", ")}"
        val enh = optional.filter { File(modelDir, it).exists() }
        return "Modelle vorhanden. " +
            if (enh.isEmpty()) "Kein Verbesserer importiert." else "Verbesserer: ${enh.joinToString(", ")}."
    }

    private fun pick(req: Int, mime: String, multi: Boolean, mimes: Array<String>?) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multi)
            if (mimes != null) putExtra(Intent.EXTRA_MIME_TYPES, mimes)
        }
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        when (req) {
            1 -> importModels(uris)
            2 -> { sources = uris; say("${uris.size} Quellfoto(s) gewählt.") }
            3 -> { targets = uris; say("${uris.size} Ziel-Datei(en) gewählt.") }
        }
    }

    private fun displayName(u: Uri): String? =
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        }

    /** Erkennt auch umbenannte Downloads wie "gfpgan_1.4 (1).onnx". */
    private fun canonicalName(raw: String): String? {
        val clean = raw.replace(Regex(" \\(\\d+\\)"), "")
        return (needed + optional).firstOrNull { it == clean }
    }

    private fun importModels(uris: List<Uri>) {
        Thread {
            try {
                for (u in uris) {
                    val raw = displayName(u) ?: continue
                    val name = canonicalName(raw)
                    if (name == null) { say("Übersprungen: $raw"); continue }
                    say("Kopiere $name ...")
                    contentResolver.openInputStream(u)?.use { inp ->
                        File(modelDir, name).outputStream().use { out -> inp.copyTo(out) }
                    }
                }
                engine = null
                say(modelStatus())
            } catch (e: Throwable) {
                say("Fehler beim Import: ${e.message}")
            }
        }.start()
    }

    private fun isVideo(u: Uri): Boolean = contentResolver.getType(u)?.startsWith("video/") == true

    private fun load(u: Uri): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > 2400) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: return null
        val orient = contentResolver.openInputStream(u)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
        } ?: 1
        val deg = when (orient) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        if (deg == 0f) return bmp
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun save(b: Bitmap, tag: String) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "mashaswape_${System.currentTimeMillis()}_$tag.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Mashaswape")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
        contentResolver.openOutputStream(uri)?.use { b.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    }

    /** Zeigt das Zielbild mit nummerierten Rahmen und wartet, bis du auswählst. null = überspringen. */
    private fun askWhichFaces(b: Bitmap, faces: List<Face>, label: String): List<Face>? {
        val latch = CountDownLatch(1)
        var result: List<Face>? = null
        runOnUiThread {
            val v = FacePickView(this, b, faces)
            val holder = ScrollView(this).apply { addView(v) }
            AlertDialog.Builder(this)
                .setTitle("$label: Gesichter antippen (grün = wird getauscht)")
                .setView(holder)
                .setPositiveButton("Tauschen") { _, _ ->
                    result = faces.filterIndexed { i, _ -> v.selected[i] }
                    latch.countDown()
                }
                .setNeutralButton("Alle") { _, _ -> result = faces; latch.countDown() }
                .setNegativeButton("Überspringen") { _, _ -> result = null; latch.countDown() }
                .setCancelable(false)
                .show()
        }
        latch.await()
        return result
    }

    private fun runSwap() {
        if (busy) return
        if (!consent.isChecked) { say("Bitte zuerst die Einwilligung bestätigen."); return }
        if (sources.isEmpty() || targets.isEmpty()) { say("Bitte Quellfotos und Ziel wählen."); return }
        val missing = needed.filter { !File(modelDir, it).exists() }
        if (missing.isNotEmpty()) { say("Fehlende Modelle: ${missing.joinToString(", ")}"); return }

        val enhMode = enhSpinner.selectedItemPosition
        val enhModels: List<Pair<String, String>> = when (enhMode) {
            1 -> listOf("gfpgan_1.4.onnx" to "gfpgan")
            2 -> listOf("codeformer.onnx" to "codeformer")
            3 -> listOf("gfpgan_1.4.onnx" to "gfpgan", "codeformer.onnx" to "codeformer")
            else -> emptyList()
        }
        val missEnh = enhModels.map { it.first }.filter { !File(modelDir, it).exists() }
        if (missEnh.isNotEmpty()) {
            say("Verbesserer-Datei fehlt: ${missEnh.joinToString(", ")}. Bitte über Schritt 1 importieren.")
            return
        }

        val strength = (strengthEdit.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 80) / 100f
        val maxSec = secEdit.text.toString().toIntOrNull()?.coerceIn(1, 60) ?: 5
        val fps = fpsEdit.text.toString().toIntOrNull()?.coerceIn(5, 30) ?: 10
        val all = allFaces.isChecked
        val ask = askFaces.isChecked

        busy = true
        Thread {
            try {
                say("Lade Modelle (beim ersten Mal dauert das) ...")
                val eng = engine ?: FaceEngine(modelDir).also { engine = it }

                val embs = ArrayList<FloatArray>()
                for ((i, u) in sources.withIndex()) {
                    say("Quellgesicht ${i + 1}/${sources.size} ...")
                    val b = load(u) ?: continue
                    val f = eng.detect(b).maxByOrNull { it.area } ?: continue
                    embs.add(eng.embed(b, f))
                }
                if (embs.isEmpty()) { say("In den Quellfotos wurde kein Gesicht gefunden."); return@Thread }
                val latent = eng.makeLatent(embs)

                var last: Bitmap? = null
                var done = 0
                for ((i, u) in targets.withIndex()) {
                    val label = "Ziel ${i + 1}/${targets.size}"
                    if (isVideo(u)) {
                        say("$label (Video) wird bearbeitet ...")
                        val okVideo = VideoProcessor.process(this, u, eng, latent, all, maxSec, fps) { msg ->
                            say("$label: $msg")
                        }
                        if (okVideo) done++
                        continue
                    }

                    say("$label: Gesichter suchen ...")
                    val b = load(u) ?: continue
                    val found = eng.detect(b).sortedByDescending { it.area }
                    if (found.isEmpty()) { say("$label: kein Gesicht gefunden."); continue }
                    val chosen: List<Face> = when {
                        ask -> askWhichFaces(b, found, label) ?: emptyList()
                        all -> found
                        else -> found.take(1)
                    }
                    if (chosen.isEmpty()) continue

                    say("$label: Gesicht wird getauscht ...")
                    var swapped = b
                    for (f in chosen) swapped = eng.swap(swapped, f, latent)

                    if (enhModels.isEmpty()) {
                        save(swapped, "$i")
                        last = swapped
                    } else {
                        for ((file, tag) in enhModels) {
                            say("$label: Verbesserer $tag läuft (kann etwas dauern) ...")
                            var out = swapped
                            for (f in chosen) out = eng.enhance(out, f, file, strength)
                            save(out, "${i}_$tag")
                            last = out
                        }
                    }
                    done++
                }
                val shown = last
                if (shown != null) runOnUiThread { preview.setImageBitmap(shown) }
                say("Fertig: $done von ${targets.size} Datei(en) gespeichert (Bilder/Mashaswape bzw. Filme/Mashaswape).")
            } catch (e: Throwable) {
                say("Fehler: ${e.message}")
            } finally {
                busy = false
            }
        }.start()
    }
}
