package com.mashaswape

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max

/** Zeigt das Zielbild mit nummerierten Rahmen; Antippen schaltet ein Gesicht an/aus (grün = wird getauscht). */
class FacePickView(ctx: Context, private val bmp: Bitmap, private val faces: List<Face>) : View(ctx) {
    val selected = BooleanArray(faces.size) { it == 0 }
    private var scale = 1f
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 44f; isFakeBoldText = true
    }
    private var downX = 0f
    private var downY = 0f

    override fun onMeasure(w: Int, h: Int) {
        val ww = MeasureSpec.getSize(w).let { if (it <= 0) 800 else it }
        scale = ww.toFloat() / bmp.width
        setMeasuredDimension(ww, max(1, (bmp.height * scale).toInt()))
    }

    override fun onDraw(c: Canvas) {
        c.drawBitmap(bmp, null, RectF(0f, 0f, bmp.width * scale, bmp.height * scale), null)
        for ((i, f) in faces.withIndex()) {
            val col = if (selected[i]) Color.rgb(0, 200, 90) else Color.rgb(230, 60, 60)
            boxPaint.color = col
            fillPaint.color = col
            val r = RectF(f.x1 * scale, f.y1 * scale, f.x2 * scale, f.y2 * scale)
            c.drawRect(r, boxPaint)
            c.drawRect(r.left, r.top, r.left + 60f, r.top + 56f, fillPaint)
            c.drawText("${i + 1}", r.left + 14f, r.top + 44f, textPaint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
            }
            MotionEvent.ACTION_UP -> {
                if (abs(e.x - downX) < 20f && abs(e.y - downY) < 20f) {
                    val bx = e.x / scale
                    val by = e.y / scale
                    var best = -1
                    var bestArea = Float.MAX_VALUE
                    for ((i, f) in faces.withIndex()) {
                        if (bx >= f.x1 && bx <= f.x2 && by >= f.y1 && by <= f.y2 && f.area < bestArea) {
                            best = i
                            bestArea = f.area
                        }
                    }
                    if (best >= 0) {
                        selected[best] = !selected[best]
                        invalidate()
                    }
                }
            }
        }
        return true
    }
}
