package com.mashaswape

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Video-Tausch: Bild für Bild auslesen, Gesicht tauschen, neu als MP4 (H.264) kodieren,
 * Originalton übernehmen. Läuft mit reduzierter Bildrate, weil der Tausch pro Bild
 * auf dem Handy mehrere Sekunden dauern kann.
 */
object VideoProcessor {

    fun process(
        ctx: Context, uri: Uri, eng: FaceEngine, latent: FloatArray,
        allFaces: Boolean, maxSec: Int, fps: Int, say: (String) -> Unit
    ): Boolean {
        val mmr = MediaMetadataRetriever()
        mmr.setDataSource(ctx, uri)
        val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val mw = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        val mh = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rot = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (durMs <= 0 || mw <= 0 || mh <= 0) {
            mmr.release()
            say("Video konnte nicht gelesen werden.")
            return false
        }

        val vw = if (rot % 180 == 90) mh else mw
        val vh = if (rot % 180 == 90) mw else mh
        val scale = min(1f, 720f / max(vw, vh))
        val w = max(16, ((vw * scale).toInt() / 16) * 16)
        val h = max(16, ((vh * scale).toInt() / 16) * 16)
        val useMs = min(maxSec * 1000L, durMs)
        val total = max(1, (useMs * fps / 1000).toInt())

        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, w * h * 8)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()

        val outFile = File(ctx.cacheDir, "mw_${System.currentTimeMillis()}.mp4")
        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG4)

        // Originalton vorbereiten
        val ex = MediaExtractor()
        var audioIdx = -1
        try {
            ex.setDataSource(ctx, uri, null)
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)
                if (mime != null && mime.startsWith("audio/")) { audioIdx = i; break }
            }
        } catch (e: Exception) {
            audioIdx = -1
        }

        var vTrack = -1
        var aTrack = -1
        var started = false
        var outCount = 0
        val info = MediaCodec.BufferInfo()

        fun drain(end: Boolean) {
            var spins = 0
            while (true) {
                val idx = enc.dequeueOutputBuffer(info, if (end) 10_000L else 0L)
                if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!end) return
                    spins++
                    if (spins > 600) return
                    continue
                }
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    vTrack = muxer.addTrack(enc.outputFormat)
                    if (audioIdx >= 0) {
                        try { aTrack = muxer.addTrack(ex.getTrackFormat(audioIdx)) } catch (e: Exception) { aTrack = -1 }
                    }
                    muxer.start()
                    started = true
                    continue
                }
                if (idx < 0) continue
                val buf = enc.getOutputBuffer(idx)
                if (buf != null && info.size > 0 && started &&
                    (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                ) {
                    // eigene, gleichmäßige Zeitstempel (Verarbeitung dauert pro Bild unterschiedlich lang)
                    info.presentationTimeUs = outCount * 1_000_000L / fps
                    outCount++
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    muxer.writeSampleData(vTrack, buf, info)
                }
                enc.releaseOutputBuffer(idx, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }

        var ok = true
        try {
            for (i in 0 until total) {
                say("Video: Bild ${i + 1} von $total ...")
                val t = i * 1_000_000L / fps
                var fr = mmr.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST, w, h) ?: break
                if (fr.width != w || fr.height != h) fr = Bitmap.createScaledBitmap(fr, w, h, true)

                var res: Bitmap = fr
                var faces = eng.detect(fr).sortedByDescending { it.area }
                if (!allFaces) faces = faces.take(1)
                for (f in faces) res = eng.swap(res, f, latent)

                val c = surface.lockCanvas(null)
                c.drawBitmap(res, 0f, 0f, null)
                surface.unlockCanvasAndPost(c)
                drain(false)
            }
            enc.signalEndOfInputStream()
            drain(true)

            if (started && aTrack >= 0) {
                try {
                    ex.selectTrack(audioIdx)
                    val limitUs = outCount * 1_000_000L / fps
                    val buf = ByteBuffer.allocate(1 shl 20)
                    val ai = MediaCodec.BufferInfo()
                    while (true) {
                        val size = ex.readSampleData(buf, 0)
                        val st = ex.sampleTime
                        if (size < 0 || st > limitUs) break
                        ai.set(0, size, st, ex.sampleFlags)
                        muxer.writeSampleData(aTrack, buf, ai)
                        ex.advance()
                    }
                } catch (e: Exception) {
                    // Ton ist optional: Video bleibt auch ohne Ton gültig
                }
            }
            if (!started) ok = false
        } catch (e: Throwable) {
            ok = false
            say("Video-Fehler: ${e.message}")
        } finally {
            try { enc.stop() } catch (e: Exception) {}
            try { enc.release() } catch (e: Exception) {}
            try { surface.release() } catch (e: Exception) {}
            try { if (started) muxer.stop() } catch (e: Exception) { ok = false }
            try { muxer.release() } catch (e: Exception) {}
            try { ex.release() } catch (e: Exception) {}
            try { mmr.release() } catch (e: Exception) {}
        }

        if (!ok) {
            outFile.delete()
            return false
        }

        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "mashaswape_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Mashaswape")
        }
        val dst = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
        if (dst == null) {
            outFile.delete()
            return false
        }
        ctx.contentResolver.openOutputStream(dst)?.use { out ->
            outFile.inputStream().use { it.copyTo(out) }
        }
        outFile.delete()
        return true
    }
}
