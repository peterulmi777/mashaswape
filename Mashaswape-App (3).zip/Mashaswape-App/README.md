# Mashaswape 1.2 – Face-Swap-App für Android (offline)

Neu in 1.2:
- Korrektur der Gesichtsausrichtung für den Tausch (laut insightface: Maßstab 1.0, x +8 px).
  Das verbessert Schärfe und Treffsicherheit.
- Optionaler Gesichts-Verbesserer: GFPGAN 1.4 und/oder CodeFormer (zusätzliche Modelldateien).
- Bei Fotos: Auswahl, welche Gesichter getauscht werden (Rahmen antippen).
- Videos als Ziel (mit Originalton), fester Signaturschlüssel.

## Modell-Dateien (in der App unter Schritt 1 importieren)
Pflicht: det_10g.onnx, w600k_r50.onnx, inswapper_128.onnx, emap.bin
Optional: gfpgan_1.4.onnx (ca. 340 MB), codeformer.onnx (ca. 377 MB)
  https://huggingface.co/facefusion/models-3.0.0/resolve/main/gfpgan_1.4.onnx
  https://huggingface.co/facefusion/models-3.0.0/resolve/main/codeformer.onnx
SHA-256 gfpgan_1.4.onnx : accc4757b26bdb89b32b4d3500d4f79c9dff97c1dd7c7104bf9dcb95e3311385
SHA-256 codeformer.onnx : 21710e7ab61c82683576c428e9c1b6fe1ed419586b7b39e394c3449c294b550f

## Update installieren
Alte Mashaswape-App EINMAL deinstallieren (andere Signatur), neue APK installieren,
Modelle erneut importieren. Danach lassen sich Updates direkt darüber installieren.

Nur mit ausdrücklicher Einwilligung der abgebildeten Personen verwenden.
Die Modelle sind nur für nicht-kommerzielle Nutzung gedacht.
